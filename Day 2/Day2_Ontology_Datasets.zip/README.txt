Palantir Foundry Training - Day 2 Ontology Datasets
Author: Rajesh Pasham

Nine Ontology-ready CSV files, one per object type. Synthetic training data,
snapshot 31 October 2026, amounts in EUR. All names, IDs and figures are fictional.

  customer.csv          296 rows   key: customer_id
  truck.csv           4,992 rows   key: truck_id
  credit_contract.csv   208 rows   key: contract_id
  lease_contract.csv    239 rows   key: lease_id
  invoice.csv         2,238 rows   key: invoice_id
  payment.csv         1,906 rows   key: payment_id
  collection_case.csv    52 rows   key: case_id
  fraud_alert.csv         4 rows   key: alert_id
  dq_issue.csv           25 rows   key: issue_id

These are prepared from the Day 1 starter data: customer records that share a
bank account are merged into one customer (customer_id), and every other file
carries that customer_id so it links to the Customer object. The original
source-system ID is kept as source_customer_id. On Day 7 you build this
preparation yourself in Pipeline Builder.

What to do (Lab 2.2 in the Day 2 lab guide):
  1. Unzip on your laptop.
  2. Upload the nine files into XX_Truck_Finance/40_ontology as datasets.
  3. Rename each to XX_ont_<name>, for example XX_ont_customer.
  4. Set the column types listed in Lab 2.2.
