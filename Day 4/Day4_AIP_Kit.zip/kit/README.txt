Day 4 AIP Kit · Palantir Foundry Training · Rajesh Pasham
No new data to upload today. These files hold the text you paste into AIP.
01_case_brief_prompt.txt     Lab 4.2  prompt for the XX Collection Case Brief Logic function
02_fraud_triage_prompt.txt   Lab 4.4  prompt for the XX Fraud Triage Brief Logic function
03_agent_instructions.txt    Lab 4.3  instructions for the XX Risk Analyst Agent
04_agent_test_questions.txt  Lab 4.3  questions to test the agent
05_eval_cases.csv            Lab 4.4  ten evaluation test cases with expected outputs
Replace XX with your initials everywhere. All data is synthetic.
