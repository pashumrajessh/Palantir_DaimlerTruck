Palantir Foundry Training - Day 1 Starter Datasets
Author: Rajesh Pasham

Nine CSV files (synthetic training data, snapshot 31 October 2026, amounts in EUR):
  customers.csv          299 rows
  dealers.csv             21 rows
  trucks.csv           4,992 rows
  credit_contracts.csv   208 rows
  lease_contracts.csv    239 rows
  invoices.csv         2,238 rows
  payments.csv         1,906 rows
  collection_cases.csv    52 rows
  fraud_watchlist.csv     25 rows

What to do (Lab 1.2 in the lab guide):
  1. Unzip this file on your laptop.
  2. Upload the nine CSV files into XX_Truck_Finance/00_starter_data as datasets.
  3. Rename each dataset to XX_<name>, where XX is your initials code.
  4. Fix the column types as described in Lab 1.2, Step 6.

All names, IDs and figures are fictional.
